a = ['S', 'L', 'R', 'R']
print(len(a))
print(a)
b = ''.join(a)
print(b)
