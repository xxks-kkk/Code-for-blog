# parser.py

import sys
from models import *
from random import shuffle


if __name__ == '__main__':
    # Load the training and test data
    print "Reading train data..."
    #train = read_data("data/train.conllx")
    #shuffle(train)
    #print "Kept " + repr(len(train)) + " exs"
    print "Reading dev data..."
    dev = read_data("data/dev.conllx")
    train2 = read_data("data/train2.conllx")
    # Here's a few sentences...
    print "Examples of sentences:"
    #print str(dev[1])
    #print str(dev[3])
    #print str(dev[5])

    parsed_dev = []
    # Set to true to produce final output
    system_to_run = sys.argv[1]
    if system_to_run == "T":
        for idx in xrange(0, len(train2)):
            parsed_sentence = train2[idx]
            print "INDEX: " + repr(idx)
            (decisions, states) = get_decision_sequence(parsed_sentence)
            parsed_dev.append(ParsedSentence(parsed_sentence.tokens, states[-1].get_dep_objs(len(parsed_sentence))))
            print_evaluation(train2, parsed_dev)            
    if system_to_run == "E":
        for idx in xrange(0, len(train2)):
            parsed_sentence = train2[idx]
            print "INDEX: " + repr(idx)
            (decisions, states) = get_decision_sequence_eager(parsed_sentence)
            parsed_dev.append(ParsedSentence(parsed_sentence.tokens, states[-1].get_dep_objs(len(parsed_sentence))))
            print_evaluation(train2, parsed_dev)            
    if system_to_run == "T1":
        for idx in xrange(0, len(dev)):
            parsed_sentence = dev[idx]
            print "INDEX: " + repr(idx)
            (decisions, states) = get_decision_sequence(parsed_sentence)
            parsed_dev.append(ParsedSentence(parsed_sentence.tokens, states[-1].get_dep_objs(len(parsed_sentence))))
            print_evaluation(dev, parsed_dev)            
    if system_to_run == "E1":
        for idx in xrange(0, len(dev)):
            parsed_sentence = dev[idx]
            print "INDEX: " + repr(idx)
            (decisions, states) = get_decision_sequence_eager(parsed_sentence)
            parsed_dev.append(ParsedSentence(parsed_sentence.tokens, states[-1].get_dep_objs(len(parsed_sentence))))
            print_evaluation(dev, parsed_dev)            
