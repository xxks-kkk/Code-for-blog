# models.py

from utils import *
from adagrad_trainer import *
from treedata import *
import numpy as np
import pickle
import gc
import os.path
import sys

# Computes the sequence of decisions and ParserStates for a gold-standard sentence using the arc-standard
# transition framework. We use the minimum stack-depth heuristic, namely that
# Invariant: states[0] is the initial state. Applying decisions[i] to states[i] yields states[i+1].
def get_decision_sequence(parsed_sentence):
    decisions = []
    states = []
    state = initial_parser_state(len(parsed_sentence))
    while not state.is_finished():
        if not state.is_legal():
            raise Exception(repr(decisions) + " " + repr(state))
        # Look at whether left-arc or right-arc would add correct arcs
        if len(state.stack) < 2:
            result = "S"
        else:
            # Stack and buffer must both contain at least one thing
            one_back = state.stack_head()
            two_back = state.stack_two_back()
            # -1 is the ROOT symbol, so this forbids attaching the ROOT as a child of anything
            # (passing -1 as an index around causes crazy things to happen so we check explicitly)
            if two_back != -1 and parsed_sentence.get_parent_idx(two_back) == one_back and state.is_complete(two_back, parsed_sentence):
                result = "L"
            # The first condition should never be true, but doesn't hurt to check
            elif one_back != -1 and parsed_sentence.get_parent_idx(one_back) == two_back and state.is_complete(one_back, parsed_sentence):
                result = "R"
            elif len(state.buffer) > 0:
                result = "S"
            else:
                result = "R" # something went wrong, buffer is empty, just do right arcs to finish the tree
        print "state: "
        print state
        decisions.append(result)
        states.append(state)
        if result == "L":
            state = state.left_arc()
        elif result == "R":
            state = state.right_arc()
        else:
            state = state.shift()
    states.append(state)
    print "states: "
    print states
    print "decisions: "
    print decisions 
    return (decisions, states)

# Computes the sequence of decisions and ParserStates for a gold-standard sentence using the arc-eager
# transition framework. We use the minimum stack-depth heuristic, namely that
# Invariant: states[0] is the initial state. Applying decisions[i] to states[i] yields states[i+1].
def get_decision_sequence_eager(parsed_sentence):
    decisions = []
    states = []
    state = initial_parser_state(len(parsed_sentence))
    while not state.is_finished():
        i = 0
        j = 0
        if not state.is_legal():
            raise Exception(repr(decisions) + " " + repr(state))
        #elif len(state.buffer) == 0:
        #    while len(state.stack) > 1:
        #        if one_back != -1:
        #            states.append(state)
        #            state = state.take_action_eager("D")
        #            decisions.append("D")
                # i += 1
                # print "i: " + str(i)
                # print "state (1): " 
                # print state
                # one_back = state.stack_head()
                # print "one_back: " + str(one_back) + " its parent: " + str(parsed_sentence.get_parent_idx(one_back))
                # if len(state.stack) == 2 and parsed_sentence.get_parent_idx(one_back) == -1:
                #     states.append(state)
                #     state = state.take_action_eager("D") 
                #     decisions.append("D")
                # #if one_back != -1 and parsed_sentence.get_parent_idx(one_back) >= 0:
                # if one_back != -1:                
                #     states.append(state)
                #     state = state.take_action_eager("D")
                #     decisions.append("D")
                #     if state.is_finished():
                #         break
                # if i >= 36:
                #     break
        #else:
        if len(state.buffer) > 0:
            # Stack and buffer must both contain at least one thing
            one_back = state.stack_head()
            #print "one_back: " + str(one_back)
            buffer_head = state.buffer_head()
            #print "buffer_head: " + str(buffer_head)
            print "buffer_head's parent: " + str(parsed_sentence.get_parent_idx(buffer_head))
            if one_back != -1:
                print "one_back's parent: " + str(parsed_sentence.get_parent_idx(one_back))
            if one_back != -1 and parsed_sentence.get_parent_idx(one_back) == buffer_head:
                print str(one_back) + "<-"  + str(buffer_head)
                result = "L"
            elif parsed_sentence.get_parent_idx(buffer_head) == one_back:
                result = "R"
            #elif state.is_complete(one_back, parsed_sentence) and parsed_sentence.get_parent_idx(one_back) >= 0:
            elif len(state.buffer) > 0:
                result = "S"
            #elif state.is_complete(one_back, parsed_sentence):
            #    result = "D"
            #else:
            #    result = "S"
            decisions.append(result)
            states.append(state)
            print "decision: " + result + " state (before action: " + result + " ): " + repr(state)
            print "-" * 16
            state = state.take_action_eager(result)
        else:
            states.append(state)
            state = state.take_action_eager("D")
            decisions.append("D")            
        #if i >= 36:
        #    break
    states.append(state)
    print "decisions: " + repr(decisions)
    print "states: " + repr(states)
    return (decisions, states)

# Stores state of a shift-reduce parser, namely the stack, buffer, and the set of dependencies that have
# already been assigned. Supports various accessors as well as the ability to create new ParserStates
# from left_arc, right_arc, and shift.
class ParserState(object):
    # stack and buffer are lists of indices
    # The stack is a list with the top of the stack being the end
    # The buffer is a list with the first item being the front of the buffer (next word)
    # deps is a dictionary mapping *child* indices to *parent* indices
    # (this is the one-to-many map; parent-to-child doesn't work in map-like data structures
    # without having the values be lists)
    def __init__(self, stack, buffer, deps, children):
        self.stack = stack
        self.buffer = buffer
        self.deps = deps  # child -> parent
        self.children = children # parent -> list of children

    def __repr__(self):
        return repr(self.stack) + " " + repr(self.buffer) + " " + repr(self.deps)

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.stack == other.stack and self.buffer == other.buffer and self.deps == other.deps
        else:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def stack_len(self):
        return len(self.stack)

    def buffer_len(self):
        return len(self.buffer)

    def is_legal(self):
        return self.stack[0] == -1

    def is_finished(self):
        return len(self.buffer) == 0 and len(self.stack) == 1

    def buffer_head(self):
        return self.get_buffer_word_idx(0)

    # Returns the buffer word at the given index
    def get_buffer_word_idx(self, index):
        if index >= len(self.buffer):
            raise Exception("Can't take the " + repr(index) + " word from the buffer of length " + repr(len(self.buffer)) + ": " + repr(self))
        return self.buffer[index]

    # Returns True if idx has all of its children attached already, False otherwise
    def is_complete(self, idx, parsed_sentence):
        _is_complete = True
        for child in range(0, len(parsed_sentence)):
            if parsed_sentence.get_parent_idx(child) == idx and (child not in self.deps.keys() or self.deps[child] != idx):
                _is_complete = False
        return _is_complete

    def stack_head(self):
        if len(self.stack) < 1:
            raise Exception("Can't go one back in the stack if there are no elements: " + repr(self))
        return self.stack[-1]

    def stack_two_back(self):
        if len(self.stack) < 2:
            raise Exception("Can't go two back in the stack if there aren't two elements: " + repr(self))
        return self.stack[-2]

    # Returns a new ParserState that is the result of taking the given action.
    # action is a string, either "L", "R", or "S"
    def take_action(self, action):
        if action == "L":
            return self.left_arc()
        elif action == "R":
            return self.right_arc()
        elif action == "S":
            return self.shift()
        else:
            raise Exception("No implementation for action " + action)

    # Returns a new ParserState that is the result of applying left arc to the current state. May crash if the
    # preconditions for left arc aren't met.
    # LeftArc: Assert a head-dependent relation between the word at the top of stack and the word directly beneath it;
    # remove the lower word from the stack.
    def left_arc(self):
        new_deps = dict(self.deps)
        new_deps.update({self.stack_two_back(): self.stack_head()})
        new_children = dict(self.children)
        if self.stack_head() not in new_children.keys():
            new_children[self.stack_head()] = [self.stack_two_back()]
        else:
            new_children[self.stack_head()].append(self.stack_two_back())
        new_stack = list(self.stack[0:-2])
        new_stack.append(self.stack_head())
        return ParserState(new_stack, self.buffer, new_deps, new_children)

    # Returns a new ParserState that is the result of applying right arc to the current state. May crash if the
    # preconditions for right arc aren't met.
    # RightArc: Assert a head-dependent relation between the second word on the stack and the word at the top; 
    # remove the word at the top of the stack
    def right_arc(self):
        new_deps = dict(self.deps)
        new_deps.update({self.stack_head(): self.stack_two_back()})
        new_children = dict(self.children)
        if self.stack_two_back() not in new_children.keys():
            new_children[self.stack_two_back()] = [self.stack_head()]
        else:
            new_children[self.stack_two_back()].append(self.stack_head())
        new_stack = list(self.stack[0:-1])
        return ParserState(new_stack, self.buffer, new_deps, new_children)

    # Returns a new ParserState that is the result of applying shift to the current state. May crash if the
    # preconditions for right arc aren't met.
    # Shift: Remove the word from the front of the input buffer and push it onto the stack.
    def shift(self):
        new_stack = list(self.stack)
        new_stack.append(self.buffer_head())
        return ParserState(new_stack, self.buffer[1:], self.deps, self.children)

    # Return the Dependency objects corresponding to the dependencies added so far to this ParserState
    def get_dep_objs(self, sent_len):
        dep_objs = []
        for i in range(0, sent_len):
            dep_objs.append(Dependency(self.deps[i], "?"))
        return dep_objs

    # Implements the arc-eager transition system

    # Returns a new ParserState that is the result of taking the given action.
    # action is a string, either "L", "R", "S", or "D"
    def take_action_eager(self, action):
        if action == "L":
            return self.left_arc_eager()
        elif action == "R":
            return self.right_arc_eager()
        elif action == "S":
            return self.shift()
        elif action == "D":
            return self.reduce_eager()
        else:
            raise Exception("No implementation for action " + action)
    
    # Returns a new ParserState that is the result of applying left arc to the current state. May crash if the
    # preconditions for left arc aren't met.
    # LeftArc: Assert a head-dependent relation between the word at the front of the input buffer and the word
    # at the top of the stack; pop the stack
    def left_arc_eager(self):
        new_deps = dict(self.deps)
        new_deps.update({self.stack_head(): self.buffer_head()})
        new_children = dict(self.children)
        if self.buffer_head() not in new_children.keys():
            new_children[self.buffer_head()] = [self.stack_head()]
        else:
            new_children[self.buffer_head()].append(self.stack_head())
        #new_stack = list(self.stack[0:-1])
        #return ParserState(new_stack, self.buffer, new_deps, new_children)
        return ParserState(self.stack[0:-1], self.buffer, new_deps, new_children)

    # Returns a new ParserState that is the result of applying right arc to the current state. May crash if the
    # preconditions for right arc aren't met.
    # RightArc: Assert a head-dependent relation between the word on the top of the stack and the word
    # at front of the input buffer; shift the word at the front of the input buffer to the stack
    def right_arc_eager(self):
        new_deps = dict(self.deps)
        new_deps.update({self.buffer_head(): self.stack_head()})        
        new_children = dict(self.children)
        if self.stack_head() not in new_children.keys():    
            new_children[self.stack_head()] = [self.buffer_head()]
        else:
            new_children[self.stack_head()].append(self.buffer_head())
        new_stack = list(self.stack)
        new_stack.append(self.buffer_head())
        return ParserState(new_stack, self.buffer[1:], new_deps, new_children)

    # Returns a new ParserState that is the result of applying reduce to the current state. May crash if the 
    # preconditions for shift aren't met.
    # Reduce: Pop the stack
    def reduce_eager(self):
        #new_stack = list(self.stack[:-1])
        #return ParserState(new_stack, self.buffer, self.deps, self.children)
        return ParserState(self.stack[:-1], self.buffer, self.deps, self.children)


# Returns an initial ParserState for a sentence of the given length. Note that because the stack and buffer
# are maintained as indices, knowing the words isn't necessary.
def initial_parser_state(sent_len):
    return ParserState([-1], range(0, sent_len), {}, {})


def get_label_indexer():
    label_indexer = Indexer()
    label_indexer.get_index("S")
    label_indexer.get_index("L")
    label_indexer.get_index("R")
    return label_indexer

def get_label_indexer_eager():
    label_indexer = Indexer()
    label_indexer.get_index("S")
    label_indexer.get_index("L")
    label_indexer.get_index("R")
    label_indexer.get_index("D")
    return label_indexer

def oracle(feature_indexer, feature_weights, state, sentence):
    # We perform logistic regression inference to figure out the decision for the current configuration
    num_decisions = 3
    label_indexer = get_label_indexer()

    feat_d_0 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(0), False)
    weights_d_0 = np.take(feature_weights, feat_d_0)
    feat_d_1 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(1), False)
    weights_d_1 = np.take(feature_weights, feat_d_1)
    feat_d_2 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(2), False)        
    weights_d_2 = np.take(feature_weights, feat_d_2)

    # Calculate the $P(y='S'|x)$
    p_y_given_x_d_0 = np.exp(np.sum(weights_d_0)) / (np.exp(np.sum(weights_d_0)) + np.exp(np.sum(weights_d_1)) + np.exp(np.sum(weights_d_2)))
    # Calculate the $P(y='L'|x)$
    p_y_given_x_d_1 = np.exp(np.sum(weights_d_1)) / (np.exp(np.sum(weights_d_0)) + np.exp(np.sum(weights_d_1)) + np.exp(np.sum(weights_d_2)))
    # Calculate the $P(y='R'|x)$
    p_y_given_x_d_2 = np.exp(np.sum(weights_d_2)) / (np.exp(np.sum(weights_d_0)) + np.exp(np.sum(weights_d_1)) + np.exp(np.sum(weights_d_2)))

    cand = np.array([p_y_given_x_d_0, p_y_given_x_d_1, p_y_given_x_d_2])
    return np.argmax(cand)


def oracle_eager(feature_indexer, feature_weights, state, sentence):
    # We perform logistic regression inference to figure out the decision for the current configuration
    # under the arc-eager transition system
    num_decisions = 4
    label_indexer = get_label_indexer_eager()

    feat_d_0 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(0), False)
    weights_d_0 = np.take(feature_weights, feat_d_0)
    feat_d_1 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(1), False)
    weights_d_1 = np.take(feature_weights, feat_d_1)
    feat_d_2 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(2), False)        
    weights_d_2 = np.take(feature_weights, feat_d_2)
    feat_d_3 = extract_features(feature_indexer, sentence, state, label_indexer.get_object(3), False)
    weights_d_3 = np.take(feature_weights, feat_d_3) 

    normalizer = np.exp(np.sum(weights_d_0)) + np.exp(np.sum(weights_d_1)) + np.exp(np.sum(weights_d_2)) + np.exp(np.sum(weights_d_3))
    # Calculate the $P(y='S'|x)$
    p_y_given_x_d_0 = np.exp(np.sum(weights_d_0)) / normalizer
    # Calculate the $P(y='L'|x)$
    p_y_given_x_d_1 = np.exp(np.sum(weights_d_1)) / normalizer
    # Calculate the $P(y='R'|x)$
    p_y_given_x_d_2 = np.exp(np.sum(weights_d_2)) / normalizer
    # Calculate the $P(y='D'|x)$
    p_y_given_x_d_3 = np.exp(np.sum(weights_d_3)) / normalizer

    cand = np.array([p_y_given_x_d_0, p_y_given_x_d_1, p_y_given_x_d_2, p_y_given_x_d_3])
    return np.argmax(cand)
    #return reversed(np.argsort(cand))


class GreedyModel(object):
    def __init__(self, feature_indexer, feature_weights):
        self.feature_indexer = feature_indexer
        self.feature_weights = feature_weights

    def parse(self, parsed_sentence):
        states = []
        state = initial_parser_state(len(parsed_sentence))
        while not state.is_finished():
            if not state.is_legal():
                raise Exception(repr(decisions) + " " + repr(state))
            if len(state.stack) < 2:
                result = "S"
            else:
                # Stack and buffer must both contain at least one thing
                one_back = state.stack_head()
                two_back = state.stack_two_back()
                # We consult Oracle to give us the right action to take: 'S','L' or 'R'
                result = oracle(self.feature_indexer, self.feature_weights, state, parsed_sentence)
                result = ["S", "L", "R"][result]
                # -1 is the ROOT symbol, so this forbids attaching the ROOT as a child of anything
                # (passing -1 as an index around causes crazy things to happen so we check explicitly)
                if two_back != -1 and result == "L":
                    result = "L"
                # The first condition should never be true, but doesn't hurt to check
                elif one_back != -1 and result == "R":
                    result = "R"
                elif result == "S" and len(state.buffer) > 0:
                    result = "S"
                else:
                    result = "R"  # something went wrong, buffer is empty, just do right arcs to finish the tree           
                states.append(state)
            state = state.take_action(result)
        states.append(state)
        return ParsedSentence(parsed_sentence.tokens, states[-1].get_dep_objs(len(parsed_sentence)))

    def parse_eager(self, parsed_sentence):
        # Parse using arc-eager transition system
        states = []
        state = initial_parser_state(len(parsed_sentence))
        while not state.is_finished():
            print "state (during parse): "
            print state
            if not state.is_legal():
                raise Exception(repr(decisions) + " " + repr(state))
            # if len(state.buffer) == 0:
            #     result = "D"
            # else:
            #     # Stack and buffer must both contain at least one thing
            #     one_back = state.stack_head()
            #     buffer_head = state.buffer_head()
            #     # We consult Oracle to give us the right action to take: 'S','L', 'R' or 'D'
            #     result = oracle_eager(self.feature_indexer, self.feature_weights, state, parsed_sentence)
            #     result = ["S", "L", "R", "D"][result]
            #     if one_back != -1:
            #         print "parsed_sentence.get_parent_idx: " + str(parsed_sentence.get_parent_idx(one_back))
            #     if one_back != -1 and parsed_sentence.get_parent_idx(one_back) >= 0:
            #         result = "L"
            if len(state.buffer) == 0:
                while len(state.stack) > 1:
                    one_back = state.stack_head()
                    print "one_back: " + str(one_back)
                    print parsed_sentence.get_parent_idx(one_back)
                    if one_back != -1 and parsed_sentence.get_parent_idx(one_back) >= 0:
                        result = "D"
                        print "before apply D: "
                        print state
                        state = state.take_action_eager(result)
                        print "after apply D: "
                        print state
                        if state.is_finished():
                            break
            else:
                # Stack and buffer must both contain at least one thing
                one_back = state.stack_head()
                buffer_head = state.buffer_head()
                # We consult Oracle to give us the right action to take: 'S','L', 'R' or 'D'
                result = oracle_eager(self.feature_indexer, self.feature_weights, state, parsed_sentence)
                result = ["S", "L", "R", "D"][result]
                if one_back != -1:
                    print "parsed_sentence.get_parent_idx: " + str(parsed_sentence.get_parent_idx(one_back))
                if one_back != -1 and parsed_sentence.get_parent_idx(one_back) == -1:
                    result = "L"
                elif result == "D" and parsed_sentence.get_parent_idx(one_back) >= 0:
                    result = "D"
                state = state.take_action_eager(result)
            states.append(state)
            print "action: " + result
        states.append(state)
        print "states (parse_eager):"
        print states
        return ParsedSentence(parsed_sentence.tokens, states[-1].get_dep_objs(len(parsed_sentence)))

def train_greedy_model(parsed_sentences):
    # We are training a classifier per state. In other words, we can batch up gradient updates on a per-sentence basis,
    # but the objective we are optimizing should be on the state level. 
    feature_indexer = Indexer()
    label_indexer = get_label_indexer()

    num_sentence = len(parsed_sentences)
    #num_sentence_use = 10
    num_sentence_use = num_sentence
    dev = read_data("data/dev.conllx")

    # About the feature cache: what is the feature cache you're computing for the sentence?
    # Think about what features you actually need: if you're doing greedy, you should only be training on states that
    # are seen in the gold derivation, so only extract features for the (state, action) pairs that you'll actually consider.
    # We build feature cache first
    # a list of 3x23 matrics with each matrix represents features associated with three actions for a given state
    feature_cache = [] 
    decision_cache = []
    for sentence in parsed_sentences[0:num_sentence_use]:
        decisions, states = get_decision_sequence(sentence)
        sys.exit(0)
        num_states = len(states[:-1])
        for s in range(num_states):
            decision_cache.append(label_indexer.get_index(decisions[s]))        
            # 23 because 23 features added in "extract_features" function
            # 3  because there are three actions can take: 'S', 'L', 'R'
            feature_matrix = np.zeros(shape=(3,23), dtype=int) 
            for d in range(3):
                feat = extract_features(feature_indexer, sentence, states[s], label_indexer.get_object(d), True)
                feature_matrix[d,:] = feat
            feature_cache.append(feature_matrix)

    feature_cache_len = len(feature_cache)
    feature_weights = np.random.rand(len(feature_indexer))

    numIters = 30
    epoch = 0
    eta = 0.2 ## learning rate
    likelihood = 0
    while True:
        for i in range(feature_cache_len):
            feature_matrix = feature_cache[i]
            decision = decision_cache[i]
            # We use the logistic regression to build our Oracle            
            weights_matrix = np.zeros(shape=(3,23))
            for d in range(3):
                weights_matrix[d,:] = np.take(feature_weights, feature_matrix[d,:]) # This is the gold action: 'S', 'L', 'R'
            sum = 0
            for d in range(3):
                sum += np.exp(np.sum(weights_matrix[d,:]))
            
            # We calculate the gradient here
            gradient_matrix = np.zeros(shape=(3,23))
            for d in range(3):
                if d == decision:
                    gradient_matrix[d,:] += 1  # This corresponds to $f_i(x_j, y_j^*)$
                p_y_given_x_d = np.exp(np.sum(weights_matrix[d,:])) / sum 
                gradient_matrix[d,:] -= p_y_given_x_d                

            # We maximize the log likelihood here
            for d in range(3):
                feature_weights[feature_matrix[d,:]] += eta * gradient_matrix[d,0]

            # Calculate the likelihood to see whether it increases
            likelihood += (np.sum(feature_weights[feature_matrix[decision,:]]) - np.log(sum))

        print "likelihood: "
        print likelihood

        # Experiment
        trained_model = GreedyModel(feature_indexer, feature_weights)
        parsed_dev = [trained_model.parse(sent) for sent in dev]
        print_evaluation(dev, parsed_dev)

        epoch += 1
        if epoch % 10 == 0:
            eta = eta * 0.1
        if epoch >= numIters:
            break
    return GreedyModel(feature_indexer,feature_weights)


def train_greedy_model_eager(parsed_sentences):
    # We are training a classifier per state. In other words, we can batch up gradient updates on a per-sentence basis,
    # but the objective we are optimizing should be on the state level. 
    feature_indexer = Indexer()
    label_indexer = get_label_indexer_eager()
    num_actions = len(label_indexer)

    num_sentence = len(parsed_sentences)
    num_sentence_use = 10
    #num_sentence_use = num_sentence
    dev = read_data("data/dev.conllx")
    train2 = read_data("data/train2.conllx")
    # a list of 4x23 matrics with each matrix represents features associated with three actions for a given state
    feature_cache = [] 
    decision_cache = []
    for sentence in parsed_sentences[0:num_sentence_use]:
        decisions, states = get_decision_sequence_eager(sentence)
        num_states = len(states[:-1])
        for s in range(num_states):
            decision_cache.append(label_indexer.get_index(decisions[s]))        
            # 23 because 23 features added in "extract_features" function
            # 4  because there are three actions can take: 'S', 'L', 'R', 'D'
            feature_matrix = np.zeros(shape=(num_actions,23), dtype=int) 
            for d in range(num_actions):
                feat = extract_features(feature_indexer, sentence, states[s], label_indexer.get_object(d), True)
                feature_matrix[d,:] = feat
            feature_cache.append(feature_matrix)

    feature_cache_len = len(feature_cache)
    feature_weights = np.random.rand(len(feature_indexer))

    numIters = 30
    epoch = 0
    eta = 0.2 ## learning rate
    likelihood = 0
    while True:
        for i in range(feature_cache_len):
            feature_matrix = feature_cache[i]
            decision = decision_cache[i]
            # We use the logistic regression to build our Oracle            
            weights_matrix = np.zeros(shape=(num_actions,23))
            for d in range(num_actions):
                weights_matrix[d,:] = np.take(feature_weights, feature_matrix[d,:]) # This is the gold action: 'S', 'L', 'R', 'D'
            sum = 0
            for d in range(num_actions):
                sum += np.exp(np.sum(weights_matrix[d,:]))
            
            # We calculate the gradient here
            gradient_matrix = np.zeros(shape=(num_actions,23))
            for d in range(num_actions):
                if d == decision:
                    gradient_matrix[d,:] += 1  # This corresponds to $f_i(x_j, y_j^*)$
                p_y_given_x_d = np.exp(np.sum(weights_matrix[d,:])) / sum 
                gradient_matrix[d,:] -= p_y_given_x_d                

            # We maximize the log likelihood here
            for d in range(num_actions):
                feature_weights[feature_matrix[d,:]] += eta * gradient_matrix[d,0]

            # Calculate the likelihood to see whether it increases
            likelihood += (np.sum(feature_weights[feature_matrix[decision,:]]) - np.log(sum))

        print "likelihood: "
        print likelihood

        # Experiment
        trained_model = GreedyModel(feature_indexer, feature_weights)
        parsed_dev = [trained_model.parse_eager(sent) for sent in train2]
        #parsed_dev = [trained_model.parse_eager(sent) for sent in dev]        
        print_evaluation(train2, parsed_dev)
        #print_evaluation(dev, parsed_dev)        

        epoch += 1
        if epoch % 10 == 0:
            eta = eta * 0.1
        if epoch >= numIters:
            break
    return GreedyModel(feature_indexer,feature_weights)


def ssvm_score(feats, weights):
    score = 0.0
    for feat in feats:
        score += weights[feat]
    return score


class BeamedModel(object):
    def __init__(self, feature_indexer, feature_weights, beam_size=3):
        self.label_indexer = get_label_indexer()
        self.feature_indexer = feature_indexer
        self.feature_weights = feature_weights
        self.beam_size = beam_size

    def parse(self, sentence):
        beam = Beam(self.beam_size)
        state = initial_parser_state(len(sentence))
        feats = extract_features(self.feature_indexer, sentence, state, "S", False)
        beam.add('S',ssvm_score(list(feats),self.feature_weights),state.take_action("S"))

        num_possible_states = 2*len(sentence)
        for action_idx in range(1, num_possible_states):
            new_beam = Beam(self.beam_size)
            for decisions, states in beam.get_elts_and_scores():
                state = beam.elts_to_states[decisions]
                for decision_idx in range(0,len(self.label_indexer)):
                    decision = self.label_indexer.get_object(decision_idx)
                    if decision != 'S' and len(state.stack) < 2:
                        continue
                    if decision == 'L' and len(state.stack) <= 2:
                        continue
                    if decision == 'S' and len(state.buffer) == 0:
                        continue
                    feats = extract_features(self.feature_indexer, sentence, state, decision, False)
                    new_beam.add(decisions+decision, states+ssvm_score(list(feats),self.feature_weights),
                             state.take_action(decision))
            beam = new_beam

        return ParsedSentence(sentence.tokens, beam.elts_to_states[beam.head()].get_dep_objs(len(sentence)))


def train_beamed_model(parsed_sentences):
    # Implement the structured SVM using the adagrad with the beam search
    beam_size = 3
    lamb = 1.0E-5                           # parameter for adagrad
    eta = 5.0                               # learning rate
    loss = 2.0                              # $l(y,y^*)$
    numIters = 10
    epoch = 0
    batch_size = 20                         # we perform weights update every batch_size sentence

    label_indexer = get_label_indexer()
    feature_indexer = Indexer()
    dev = read_data("data/dev.conllx")      # for the experiment purpose
    num_sentence = len(parsed_sentences)
    num_sentence_use = num_sentence

    feature_cache = [[[] for step in range(2*len(parsed_sentences[i]))] for i in range(len(parsed_sentences))]
    for sentence_idx, sentence in enumerate(parsed_sentences):
        decisions, states = get_decision_sequence(sentence)
        for action_idx in range(len(decisions)):
            feature_cache[sentence_idx][action_idx] = extract_features(feature_indexer, 
                                                                       sentence, 
                                                                       states[action_idx], 
                                                                       decisions[action_idx], 
                                                                       True)

    feature_weights = np.zeros(len(label_indexer)*len(feature_indexer),np.float)
    trainer = AdagradTrainer(feature_weights, lamb, eta)

    grad = Counter()
    while True:
        print("# of epoch =", epoch)
        for sentence_idx, sentence in enumerate(parsed_sentences[:num_sentence_use]):
            if sentence_idx % batch_size == 0:
                trainer.apply_gradient_update(grad, batch_size)
                # We want to resets the indices after each gradient update
                grad = Counter()
            
            early_stopping = False
            gold_decisions, _ = get_decision_sequence(sentence)
            gold_decisions = ''.join(gold_decisions)

            # Initialization step 
            beam = Beam(beam_size)
            state = initial_parser_state(len(parsed_sentences[sentence_idx]))
            feats = extract_features(feature_indexer, 
                                     sentence, 
                                     state, 
                                     "S", 
                                     False)
            beam.add("S",trainer.score(list(feats)),state.take_action("S"))

            # Recursion step
            for action_idx in range(1, len(gold_decisions)):
                new_beam = Beam(beam_size)
                for decisions, score in beam.get_elts_and_scores():
                    state = beam.elts_to_states[decisions]
                    for decision_idx in range(len(label_indexer)):
                        decision = label_indexer.get_object(decision_idx)
                        if decision != 'S' and len(state.stack) < 2:
                            continue
                        if decision == 'L' and len(state.stack) <= 2:
                            continue
                        if decision == 'S' and len(state.buffer) == 0:
                            continue
                        feats = extract_features(feature_indexer, 
                                                 parsed_sentences[sentence_idx],
                                                 state, 
                                                 decision, 
                                                 False)
                        new_beam.add(decisions+decision, score+trainer.score(list(feats)), state.take_action(decision))

                # The output of new_beam.get_predictions() will be, for example, ['SSLSSLL', 'SSLSSSL', 'SSLSSLS']
                # If the gold decision sequence not in the predicted decision sequence list, then we perform early stop
                if gold_decisions[:(action_idx+1)] not in new_beam.get_predictions():
                    for k in range(action_idx+1):
                        feats = feature_cache[sentence_idx][k]
                        grad.add(Counter(list(feats)))

                    # The output of new_beam.head() will be, for example, SSLSSLL
                    prediction = new_beam.head()
                    state = initial_parser_state(len(parsed_sentences[sentence_idx]))
                    for k in range(len(prediction)):
                        feats = extract_features(feature_indexer, 
                                                 parsed_sentences[sentence_idx],
                                                 state, 
                                                 prediction[k], 
                                                 False)
                        grad.subtract(Counter(list(feats)))
                        state = state.take_action(prediction[k])
                    early_stopping = True
                    break
                beam = new_beam

            if not early_stopping:
                prediction = beam.head()
                if gold_decisions == prediction:
                    # Here, we want to check the competing candidate of our prediction
                    # and make its weights lower than its originals so that our prediction
                    # weights become more significant
                    try:
                        prediction = beam.get_predictions()[1]
                    except:
                        continue
                    if (beam.scores[0] - beam.scores[1]) > loss:
                        continue

                for k in range(len(gold_decisions)):
                    feats = feature_cache[sentence_idx][k]
                    grad.add(Counter(list(feats)))

                state = initial_parser_state(len(parsed_sentences[sentence_idx]))
                for k in range(len(prediction)):
                    feats = extract_features(feature_indexer, 
                                             parsed_sentences[sentence_idx],
                                             state, 
                                             prediction[k], 
                                             False)
                    grad.subtract(Counter(list(feats)))
                    state = state.take_action(prediction[k])

        # Experiments
        trained_model = BeamedModel(feature_indexer=feature_indexer, feature_weights=trainer.weights, beam_size=3)
        parsed_dev = [trained_model.parse(sent) for sent in dev]
        print_evaluation(dev, parsed_dev)

        epoch += 1
        if epoch >= numIters:
            break
    return BeamedModel(feature_indexer=feature_indexer, feature_weights=trainer.weights, beam_size=3)

# Extract features for the given decision in the given parser state. Features look at the top of the
# stack and the start of the buffer. Note that this isn't in any way a complete feature set -- play around with
# more of your own!
def extract_features(feat_indexer, sentence, parser_state, decision, add_to_indexer):
    feats = []
    sos_tok = Token("<s>", "<S>", "<S>")
    root_tok = Token("<root>", "<ROOT>", "<ROOT>")
    eos_tok = Token("</s>", "</S>", "</S>")
    if parser_state.stack_len() >= 1:
        head_idx = parser_state.stack_head()
        stack_head_tok = sentence.tokens[head_idx] if head_idx != -1 else root_tok
        if parser_state.stack_len() >= 2:
            two_back_idx = parser_state.stack_two_back()
            stack_two_back_tok = sentence.tokens[two_back_idx] if two_back_idx != -1 else root_tok
        else:
            stack_two_back_tok = sos_tok
    else:
        stack_head_tok = sos_tok
        stack_two_back_tok = sos_tok
    buffer_first_tok = sentence.tokens[parser_state.get_buffer_word_idx(0)] if parser_state.buffer_len() >= 1 else eos_tok
    buffer_second_tok = sentence.tokens[parser_state.get_buffer_word_idx(1)] if parser_state.buffer_len() >= 2 else eos_tok
    # Shortcut for adding features
    def add_feat(feat):
        maybe_add_feature(feats, feat_indexer, add_to_indexer, feat)
    add_feat(decision + ":S0Word=" + stack_head_tok.word)
    add_feat(decision + ":S0Pos=" + stack_head_tok.pos)
    add_feat(decision + ":S0CPos=" + stack_head_tok.cpos)
    add_feat(decision + ":S1Word=" + stack_two_back_tok.word)
    add_feat(decision + ":S1Pos=" + stack_two_back_tok.pos)
    add_feat(decision + ":S1CPos=" + stack_two_back_tok.cpos)
    add_feat(decision + ":B0Word=" + buffer_first_tok.word)
    add_feat(decision + ":B0Pos=" + buffer_first_tok.pos)
    add_feat(decision + ":B0CPos=" + buffer_first_tok.cpos)
    add_feat(decision + ":B1Word=" + buffer_second_tok.word)
    add_feat(decision + ":B1Pos=" + buffer_second_tok.pos)
    add_feat(decision + ":B1CPos=" + buffer_second_tok.cpos)
    add_feat(decision + ":S1S0Pos=" + stack_two_back_tok.pos + "&" + stack_head_tok.pos)
    add_feat(decision + ":S0B0Pos=" + stack_head_tok.pos + "&" + buffer_first_tok.pos)
    add_feat(decision + ":S1B0Pos=" + stack_two_back_tok.pos + "&" + buffer_first_tok.pos)
    add_feat(decision + ":S0B1Pos=" + stack_head_tok.pos + "&" + buffer_second_tok.pos)
    add_feat(decision + ":B0B1Pos=" + buffer_first_tok.pos + "&" + buffer_second_tok.pos)
    add_feat(decision + ":S0B0WordPos=" + stack_head_tok.word + "&" + buffer_first_tok.pos)
    add_feat(decision + ":S0B0PosWord=" + stack_head_tok.pos + "&" + buffer_first_tok.pos)
    add_feat(decision + ":S1S0WordPos=" + stack_two_back_tok.word + "&" + stack_head_tok.pos)
    add_feat(decision + ":S1S0PosWord=" + stack_two_back_tok.pos + "&" + stack_head_tok.word)
    add_feat(decision + ":S1S0B0Pos=" + stack_two_back_tok.pos + "&" + stack_head_tok.pos + "&" + buffer_first_tok.pos)
    add_feat(decision + ":S0B0B1Pos=" + stack_head_tok.pos + "&" + buffer_first_tok.pos + "&" + buffer_second_tok.pos)
    return feats

